# impressingCrush
link mobile.js instead of script.js in index.html to work in mobile.

![image](https://github.com/developerrahulofficial/impressingCrush/assets/83329806/1a50454f-634d-4d5b-8f8a-ef2333f366c9)


Thanks and Happy Coding.
